# Rest Server Support PHP5 With CodeIgniter-3.1.11

Check the recent version at https://github.com/chriskacerguis/codeigniter-restserver
